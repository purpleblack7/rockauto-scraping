# rockauto-scraping


This project is my attempt to learn to scrape from the web. The website I'll be scraping is RockAuto. Because they have a simpler website, it will be easier for me to scrape prices from their site.
